//
//  MilestoneOne_PeterWelchApp.swift
//  MilestoneOne-PeterWelch
//
//  Created by Pete Welch on 14/3/21.
//

import SwiftUI

@main
struct MilestoneOne_PeterWelchApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
